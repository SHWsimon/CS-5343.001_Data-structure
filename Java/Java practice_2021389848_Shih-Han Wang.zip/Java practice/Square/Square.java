//import java.util.Scanner;
public class Square
{
	private int length;
	
	public void setlen()
	{
		length=1;
	}
	
	public void getlen(int l)
	{
		length=l;
	}
	
	public int getArea()
	{
		return length*length; 
	}
} 